const mongoose = require('mongoose');
const Trip = require('../models/travlr');
const Model = mongoose.model('trips');

//required trip feilds
const requiredTripFields = [
    'code',
    'name',
    'length',
    'start',
    'resort',
    'perPerson',
    'image',
    'description'
];

//checks for missing feilds
const validateTripInput = (body) => {
    return requiredTripFields.filter((field) => {
        const value = body[field];

        return value === undefined ||
            value === null ||
            (typeof value === 'string' && value.trim() === '');
    });
};

//get all trips
const tripsList = async (req, res) => {
    try {
        const trips = await Model
            .find({})
            .exec();

        return res
            .status(200)
            .json(trips);
    } catch (err) {
        console.error('Error retrieving trips:', err);

        return res
            .status(500)
            .json({ message: 'Unable to retrieve trips.' });
    }
};

//gets a trip by its code
const tripsFindByCode = async (req, res) => {
    try {
        const trip = await Model
            .findOne({ code: req.params.tripCode })
            .exec();

        //if trip is not found
        if (!trip) {
            return res
                .status(404)
                .json({ message: 'Trip not found.' });
        }

        return res
            .status(200)
            .json(trip);
    } catch (err) {
        
        console.error('Error retrieving trip:', err);

        return res
            .status(500)
            .json({ message: 'Unable to retrieve trip.' });
    }
};

//adds new trip
const tripsAddTrip = async (req, res) => {
    const missingFields = validateTripInput(req.body);

    //validates all feilds were entered
    if (missingFields.length > 0) {
        return res
            .status(400)
            .json({
                message: 'Missing required trip information.',
                fields: missingFields
            });
    }

    try {
        const newTrip = new Trip({
            code: req.body.code,
            name: req.body.name,
            length: req.body.length,
            start: req.body.start,
            resort: req.body.resort,
            perPerson: req.body.perPerson,
            image: req.body.image,
            description: req.body.description
        });

        const trip = await newTrip.save();

        return res
            .status(201)
            .json(trip);
    } catch (err) {
        console.error('Error creating trip:', err);

        
        if (err.name === 'ValidationError') {
            return res
                .status(400)
                .json({ message: 'Invalid trip information.' });
        }

        return res
            .status(500)
            .json({ message: 'Unable to create trip.' });
    }
};

//updates an existing trip
const tripsUpdateTrip = async (req, res) => {
    const missingFields = validateTripInput(req.body);

    //sttops incomplete information from replacing valid trip 
    if (missingFields.length > 0) {
        return res
            .status(400)
            .json({
                message: 'Missing required trip information.',
                fields: missingFields
            });
    }

    try {
        const trip = await Model
            .findOneAndUpdate(
                { code: req.params.tripCode },
                {
                    code: req.body.code,
                    name: req.body.name,
                    length: req.body.length,
                    start: req.body.start,
                    resort: req.body.resort,
                    perPerson: req.body.perPerson,
                    image: req.body.image,
                    description: req.body.description
                },
                {
                    new: true,
                    runValidators: true
                }
            )
            .exec();

        if (!trip) {
            return res
                .status(404)
                .json({ message: 'Trip not found.' });
        }

        //returns updated trip
        return res
            .status(200)
            .json(trip);
    } catch (err) {
        console.error('Error updating trip:', err);

        if (err.name === 'ValidationError') {
            return res
                .status(400)
                .json({ message: 'Invalid trip information.' });
        }

        return res
            .status(500)
            .json({ message: 'Unable to update trip.' });
    }
};

module.exports = {
    tripsList,
    tripsFindByCode,
    tripsAddTrip,
    tripsUpdateTrip
};