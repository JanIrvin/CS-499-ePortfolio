const passport = require('passport');
const User = require('../models/user');

// Register a new user
const register = async (req, res) => {
    if (!req.body.name || !req.body.email || !req.body.password) {
        return res
            .status(400)
            .json({ message: 'All fields required' });
    }

    const user = new User({
        name: req.body.name,
        email: req.body.email
    });

    user.setPassword(req.body.password);

    try {
        const savedUser = await user.save();

        const token = savedUser.generateJWT();

        res
            .status(200)
            .json({ token });
    } catch (err) {
        res
            .status(400)
            .json(err);
    }
};

// Login an existing user
const login = (req, res) => {
    if (!req.body.email || !req.body.password) {
        return res
            .status(400)
            .json({ message: 'All fields required' });
    }

    passport.authenticate('local', (err, user, info) => {
        if (err) {
            return res
                .status(404)
                .json(err);
        }

        if (user) {
            const token = user.generateJWT();

            return res
                .status(200)
                .json({ token });
        }

        return res
            .status(401)
            .json(info);
    })(req, res);
};

// Export methods that drive endpoints
module.exports = {
    register,
    login
};