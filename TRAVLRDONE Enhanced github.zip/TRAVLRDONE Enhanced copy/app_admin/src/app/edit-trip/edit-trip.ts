import { Component, OnInit } from '@angular/core';
import { CommonModule } from '@angular/common';
import { Router } from '@angular/router';
import {
  FormBuilder,
  FormGroup,
  Validators,
  ReactiveFormsModule
} from '@angular/forms';

import { TripDataService } from '../services/trip-data';
import { Trip } from '../models/trip';

@Component({
  selector: 'app-edit-trip',
  standalone: true,
  imports: [CommonModule, ReactiveFormsModule],
  templateUrl: './edit-trip.html',
  styleUrl: './edit-trip.css'
})
export class EditTrip implements OnInit {

  public editForm: FormGroup;
  trip!: Trip;
  submitted = false;
  message = '';

  constructor(
    private formBuilder: FormBuilder,
    private router: Router,
    private tripDataService: TripDataService
  ) {
    this.editForm = this.formBuilder.group({
      _id: [''],
      code: ['', Validators.required],
      name: ['', Validators.required],
      length: ['', Validators.required],
      start: ['', Validators.required],
      resort: ['', Validators.required],
      perPerson: ['', Validators.required],
      image: ['', Validators.required],
      description: ['', Validators.required]
    });
  }

  ngOnInit(): void {

    const tripCode = localStorage.getItem('tripCode');

    if (!tripCode) {
      alert("Something went wrong. Couldn't find the trip code!");
      this.router.navigate(['/']);
      return;
    }

    console.log('EditTrip::ngOnInit');
    console.log('tripCode:', tripCode);

    this.tripDataService.getTrip(tripCode).subscribe({
      next: (value: Trip[]) => {

        console.log('Trip retrieved:', value);

        if (!value || value.length === 0) {
          this.message = 'No Trip Retrieved!';
          return;
        }

        this.trip = value[0];

        this.editForm.patchValue(this.trip);

        this.message = 'Trip: ' + tripCode + ' retrieved';

        console.log(this.message);
      },

      error: (error: any) => {
        console.log('Error getting trip:', error);
        this.message = 'Error retrieving trip.';
      }
    });
  }

  public onSubmit(): void {

    this.submitted = true;

    if (this.editForm.valid) {

      this.tripDataService.updateTrip(this.editForm.value).subscribe({
        next: (value: any) => {
          console.log('Trip updated:', value);
          this.router.navigate(['/']);
        },

        error: (error: any) => {
          console.log('Error updating trip:', error);
        }
      });
    }
  }

  get f() {
    return this.editForm.controls;
  }
}