import { Routes } from '@angular/router';
import { TripListingComponent } from './trip-listing/trip-listing';
import { AddTripComponent } from './add-trip/add-trip';
import { EditTrip } from './edit-trip/edit-trip';
import { Login } from './login/login';

export const routes: Routes = [
  {
    path: 'add-trip',
    component: AddTripComponent
  },
  {
    path: 'edit-trip',
    component: EditTrip
  },
  {
    path: 'login',
    component: Login
  },
  {
    path: '',
    component: TripListingComponent,
    pathMatch: 'full'
  }
];